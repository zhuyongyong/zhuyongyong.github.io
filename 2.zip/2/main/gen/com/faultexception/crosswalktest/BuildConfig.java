/** Automatically generated file. DO NOT MODIFY */
package com.faultexception.crosswalktest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}