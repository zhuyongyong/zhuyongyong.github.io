package com.faultexception.crosswalktest;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.xwalk.core.XWalkResourceClient;
import org.xwalk.core.XWalkUIClient;
import org.xwalk.core.XWalkView;
import org.xwalk.core.XWalkWebResourceRequest;
import org.xwalk.core.XWalkWebResourceResponse;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

/**
 * Created by Daniel on 12/5/2015.
 */
public class StockTestView extends WebView {

    public StockTestView(Context context) {
        super(context);
        loadUrl("file:///test");


        setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if ("file:///test".equals(request.getUrl().toString())) {

                    StringBuilder contentBuilder = new StringBuilder();
                    contentBuilder.append("<meta name=\"viewport\" content=\"width=1000, height=1000, user-scalable=no\">");
                    contentBuilder.append("<div style='-webkit-column-width:1000px; height: 1000px;'>");
                    for (int i = 0; i < 2000; ++i) {
                        contentBuilder.append("Test ");
                    }
                    contentBuilder.append("</div>");
                    return new WebResourceResponse("text/html", "UTF-8",
                            new ByteArrayInputStream(contentBuilder.toString()
                                    .getBytes(StandardCharsets.UTF_8)));
                }
                return super.shouldInterceptRequest(view, request);
            }
        });
    }
}
