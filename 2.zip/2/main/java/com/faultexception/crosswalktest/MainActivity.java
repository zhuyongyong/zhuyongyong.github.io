package com.faultexception.crosswalktest;

import android.app.ActionBar;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.RelativeLayout;

import org.xwalk.core.XWalkApplication;
import org.xwalk.core.XWalkSettings;
import org.xwalk.core.XWalkView;

public class MainActivity extends AppCompatActivity {

    private ViewGroup mContainerView;
    private View mWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mContainerView = (ViewGroup) findViewById(R.id.container);

        loadCrosswalk();

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int curZoom;
                int newZoom;
                if (mWebView instanceof XWalkView) {
                    curZoom = ((XWalkView) mWebView).getSettings().getTextZoom();
                } else {
                    curZoom = ((WebView) mWebView).getSettings().getTextZoom();
                }
                newZoom = curZoom == 100 ? 200 : 100;
                if (mWebView instanceof XWalkView) {
                    ((XWalkView) mWebView).getSettings().setTextZoom(newZoom);
                } else {
                    ((WebView) mWebView).getSettings().setTextZoom(newZoom);
                }
                Snackbar.make(mWebView, "Zoom set to " + newZoom + "%",
                        Snackbar.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    private void loadCrosswalk() {
        mContainerView.removeAllViews();

        mWebView = new XWalkTestView(this);
        mContainerView.addView(mWebView, RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT);

        setTitle("Crosswalk");
    }

    private void loadStock() {
        mContainerView.removeAllViews();

        mWebView = new StockTestView(this);
        mContainerView.addView(mWebView, RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT);

        setTitle("Stock");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        switch (id) {
        case R.id.action_swap_stock:
            loadStock();
            return true;
        case R.id.action_swap_x:
            loadCrosswalk();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
