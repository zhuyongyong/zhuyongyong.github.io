package com.example.testing;

import org.xwalk.core.XWalkActivity;
import org.xwalk.core.XWalkView;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

public class MainActivity extends XWalkActivity {

    private ViewGroup mContainerView;
    private XWalkView xwalkView;
    private View mWebView;

	@Override
	protected void onXWalkReady() {
//        mContainerView.addView(xwalkView, RelativeLayout.LayoutParams.MATCH_PARENT,
//                RelativeLayout.LayoutParams.MATCH_PARENT);
        xwalkView.load("file:///android_asset/text_zoom.html", null);
//		xwalkView.getSettings().setTextZoom(200);
	}
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
//		mContainerView = (ViewGroup) findViewById(R.id.container);
//        xwalkView = new XWalkTestView(this);
		xwalkView = (XWalkView) findViewById(R.id.xwalkview);

	}

//	@Override
//	public boolean onCreateOptionsMenu(Menu menu) {
//		// Inflate the menu; this adds items to the action bar if it is present.
//		getMenuInflater().inflate(R.menu.main, menu);
//		return true;
//	}
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        switch (id) {
//        case R.id.action_swap_stock:
//        	loadWebView();
//            return true;
//        case R.id.action_swap_x:
//        	loadXWalkView();
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }
//
//    private void loadXWalkView() {
//        mContainerView.removeAllViews();
//
//        mWebView = new XWalkTestView(this);
//        mContainerView.addView(mWebView, RelativeLayout.LayoutParams.MATCH_PARENT,
//                RelativeLayout.LayoutParams.MATCH_PARENT);
//
//        setTitle("XWalkView");
//    }
//
//    private void loadWebView() {
//        mContainerView.removeAllViews();
//
//        mWebView = new StockTestView(this);
//        mContainerView.addView(mWebView, RelativeLayout.LayoutParams.MATCH_PARENT,
//                RelativeLayout.LayoutParams.MATCH_PARENT);
//
//        setTitle("WebView");
//    }

}
