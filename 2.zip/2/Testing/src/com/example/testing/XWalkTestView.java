package com.example.testing;

import android.annotation.SuppressLint;
import android.content.Context;

import org.xwalk.core.XWalkResourceClient;
import org.xwalk.core.XWalkView;
import org.xwalk.core.XWalkWebResourceRequest;
import org.xwalk.core.XWalkWebResourceResponse;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

public class XWalkTestView extends XWalkView {

    public XWalkTestView(Context context) {
        super(context);
        load("file:///test", null);


        setResourceClient(new XWalkResourceClient(this) {
            @SuppressLint("NewApi")
			@Override
            public XWalkWebResourceResponse shouldInterceptLoadRequest(XWalkView view,
                    XWalkWebResourceRequest request) {
                if ("file:///test".equals(request.getUrl().toString())) {

                    StringBuilder contentBuilder = new StringBuilder();
                    contentBuilder.append("<meta name=\"viewport\" content=\"width=1000, height=1000, user-scalable=no\">");
                    contentBuilder.append("<div style='-webkit-column-width:1000px; height: 1000px;'>");
                    for (int i = 0; i < 2000; ++i) {
                        contentBuilder.append("Test ");
                    }
                    contentBuilder.append("</div>");
                    return createXWalkWebResourceResponse("text/html", "UTF-8",
                            new ByteArrayInputStream(contentBuilder.toString()
                                    .getBytes(StandardCharsets.UTF_8)));
                }
                return super.shouldInterceptLoadRequest(view, request);
            }
        });
    }
}
